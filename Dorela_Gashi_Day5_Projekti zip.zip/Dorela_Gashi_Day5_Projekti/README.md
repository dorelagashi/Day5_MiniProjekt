# Study Group Finder

## Përshkrimi i projektit

Study Group Finder është një aplikacion i zhvilluar me Flutter që u ndihmon studentëve të gjejnë dhe të krijojnë grupe për të mësuar së bashku.

## Teknologjitë

* Flutter dhe Dart
* Supabase
* Supabase Authentication
* REST API dhe HTTP
* JSON

## Funksionet kryesore

* Regjistrimi dhe hyrja në llogari
* Shfaqja e grupeve nga Supabase
* Kërkimi sipas lëndës, vendit dhe orarit
* Filtrimi sipas lëndës dhe grupeve të lira
* Krijimi i grupeve të reja
* Ndryshimi dhe fshirja e grupeve të krijuara nga përdoruesi
* Shfaqja e detajeve të grupit
* Anëtarësimi në grupe dhe largimi prej tyre
* Faqja “Të miat”
* Profili dhe dalja nga llogaria
* Modaliteti i errët
* Rifreskimi i të dhënave

## Baza e të dhënave

Aplikacioni përdor Supabase me tabelat `groups` dhe `members`. Qasja në të dhëna kontrollohet përmes autentikimit dhe politikave RLS të konfiguruara në Supabase.

## Si përdoret

1. Regjistrohu ose hyr në llogari.
2. Shiko grupet e disponueshme.
3. Përdor kërkimin dhe filtrat.
4. Krijo një grup duke plotësuar formularin.
5. Hap një grup për të parë detajet.
6. Përdor skedat “Grupet”, “Të miat” dhe “Profili”.

## Autori

Emri dhe mbiemri: [Shkruaj emrin dhe mbiemrin tënd]

## Shënim

Projekti duhet të testohet para dorëzimit. Përmbajtja e këtij dokumenti duhet të përputhet me funksionet që janë realisht të përfunduara në aplikacion.
